import React from "react";
import Cal from "./calendar/Calendar";

const Calendar = () => {
  return (
    <div className="sub-container">
      <Cal />
    </div>
  );
};

export default Calendar;
