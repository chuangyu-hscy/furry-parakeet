import React from "react";

const Search = () => {
  return (
    <div className="sub-container">
      <h1>Search Page</h1>
    </div>
  );
};

export default Search;
